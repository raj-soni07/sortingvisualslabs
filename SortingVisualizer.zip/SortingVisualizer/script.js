const $ = (id) => document.getElementById(id);
const algorithms = {
  bubble: {name:'Bubble Sort', complexity:'O(n²)', best:'O(n)', average:'O(n²)', worst:'O(n²)', stable:'Yes', icon:'↕', badge:'BEGINNER FRIENDLY', description:'Compare adjacent values and swap them until the array is sorted.', text:'Bubble Sort repeatedly checks neighbouring elements and swaps them if they are in the wrong order. Larger values gradually move toward the end, like bubbles rising.'},
  selection: {name:'Selection Sort', complexity:'O(n²)', best:'O(n²)', average:'O(n²)', worst:'O(n²)', stable:'No', icon:'⌄', badge:'SIMPLE & DIRECT', description:'Find the smallest remaining value and place it in the next position.', text:'Selection Sort looks through the unsorted part to find the smallest value, then places it at the front. It makes fewer swaps, but still checks many values.'},
  insertion: {name:'Insertion Sort', complexity:'O(n²)', best:'O(n)', average:'O(n²)', worst:'O(n²)', stable:'Yes', icon:'↦', badge:'GREAT FOR SMALL ARRAYS', description:'Take each value and insert it into its correct place in the sorted section.', text:'Insertion Sort builds a sorted section one item at a time. Each new value moves left until it reaches its correct position, much like arranging cards in your hand.'},
  merge: {name:'Merge Sort', complexity:'O(n log n)', best:'O(n log n)', average:'O(n log n)', worst:'O(n log n)', stable:'Yes', icon:'⑂', badge:'DIVIDE & CONQUER', description:'Divide the array into smaller parts, then merge them back in order.', text:'Merge Sort splits the array into smaller halves until each part has one value. It then merges the parts in sorted order. Its running time stays O(n log n) across cases.'},
  quick: {name:'Quick Sort', complexity:'O(n log n)*', best:'O(n log n)', average:'O(n log n)', worst:'O(n²)', stable:'No', icon:'⚡', badge:'FAST IN PRACTICE', description:'Choose a pivot and partition values around it, then sort each side.', text:'Quick Sort picks a pivot value and places smaller values on one side and larger values on the other. It repeats this on each side. Its average performance is fast, but a poor pivot can lead to O(n²).'},
  heap: {name:'Heap Sort', complexity:'O(n log n)', best:'O(n log n)', average:'O(n log n)', worst:'O(n log n)', stable:'No', icon:'♜', badge:'HEAP POWERED', description:'Use a heap to repeatedly move the next largest value into place.', text:'Heap Sort organises values into a binary max-heap. It repeatedly moves the largest value to the end and rebuilds the heap. It has O(n log n) time and uses little extra memory.'}
};
let values = [], selectedAlgo = 'bubble', order = 'asc', running = false, paused = false, stopRequested = false;
let comparisons = 0, swaps = 0, startedAt = 0, elapsedBefore = 0, timerHandle = null, generator = null, sortedIndices = new Set(), stepMode = false, stepResolve = null;
const bars = $('bars');

function randomArray(size = Number($('sizeSlider').value)) {
  values = Array.from({length:size}, () => Math.floor(Math.random()*96)+5);
  sortedIndices = new Set(); comparisons = 0; swaps = 0; elapsedBefore = 0;
  updateStats(); renderBars(); $('statusText').textContent = 'Ready to sort'; $('arrayCaption').textContent = `${values.length} values · random order`;
}
function renderBars(active = {}) {
  bars.innerHTML = '';
  const showValues = values.length <= 20;
  values.forEach((v,i) => {
    const bar = document.createElement('div'); bar.className = 'bar';
    if (sortedIndices.has(i)) bar.classList.add('sorted');
    if (active.compare?.includes(i)) bar.className = 'bar compare';
    if (active.swap?.includes(i)) bar.className = 'bar swap';
    if (active.pivot === i) bar.className = 'bar pivot';
    if (sortedIndices.has(i) && !active.compare?.includes(i) && !active.swap?.includes(i) && active.pivot !== i) bar.classList.add('sorted');
    bar.style.height = `${Math.max(4,v)}%`;
    if (showValues) { bar.classList.add('show-value'); const label=document.createElement('span');label.className='bar-value';label.textContent=v;bar.appendChild(label); }
    bar.setAttribute('aria-label',`Value ${v}`); bars.appendChild(bar);
  });
}
function updateStats(){ $('comparisons').textContent=comparisons.toLocaleString(); $('swaps').textContent=swaps.toLocaleString(); $('complexity').textContent=algorithms[selectedAlgo].complexity; }
function updateElapsed(){ if(!running || paused) return; $('elapsed').innerHTML=((elapsedBefore+(performance.now()-startedAt))/1000).toFixed(2)+'<span class="stat-unit">s</span>'; }
function setElapsedStopped(){ if(running && !paused) elapsedBefore += performance.now()-startedAt; running=false; clearInterval(timerHandle); $('elapsed').innerHTML=(elapsedBefore/1000).toFixed(2)+'<span class="stat-unit">s</span>'; }
function updateAlgorithmInfo(){const a=algorithms[selectedAlgo];$('visualDescription').textContent=a.description;$('complexity').textContent=a.complexity;$('learnIcon').textContent=a.icon;$('learnTitle').textContent=a.name;$('learnText').textContent=a.text;$('bestCase').textContent=a.best;$('averageCase').textContent=a.average;$('worstCase').textContent=a.worst;$('stableValue').textContent=a.stable;$('learnBadge').textContent=a.badge;}
function speedDelay(){const s=Number($('speedSlider').value);return Math.max(5,Math.round(510*Math.pow(1-s/100,2)+7));}
function isOutOfOrder(a,b){return order==='asc'?a>b:a<b;}
function* bubbleSort(a){for(let i=0;i<a.length-1;i++){let changed=false;for(let j=0;j<a.length-i-1;j++){comparisons++;yield {compare:[j,j+1]};if(isOutOfOrder(a[j],a[j+1])){[a[j],a[j+1]]=[a[j+1],a[j]];swaps++;changed=true;yield {swap:[j,j+1]};}}sortedIndices.add(a.length-i-1);yield {};if(!changed){for(let k=0;k<a.length-i-1;k++)sortedIndices.add(k);break;}}}
function* selectionSort(a){for(let i=0;i<a.length-1;i++){let best=i;for(let j=i+1;j<a.length;j++){comparisons++;yield {compare:[best,j]};if(isOutOfOrder(a[best],a[j]))best=j;}if(best!==i){[a[i],a[best]]=[a[best],a[i]];swaps++;yield {swap:[i,best]};}sortedIndices.add(i);yield {};}if(a.length)sortedIndices.add(a.length-1);}
function* insertionSort(a){for(let i=1;i<a.length;i++){let key=a[i],j=i-1;while(j>=0){comparisons++;yield {compare:[j,j+1]};if(!isOutOfOrder(a[j],key))break;a[j+1]=a[j];swaps++;yield {swap:[j,j+1]};j--;}a[j+1]=key;yield {compare:[j+1]};}for(let i=0;i<a.length;i++)sortedIndices.add(i);}
function* mergeSort(a){function* merge(l,m,r){let left=a.slice(l,m+1),right=a.slice(m+1,r+1),i=0,j=0,k=l;while(i<left.length&&j<right.length){comparisons++;yield {compare:[l+i,m+1+j]};if(order==='asc'?left[i]<=right[j]:left[i]>=right[j])a[k++]=left[i++];else a[k++]=right[j++];swaps++;yield {swap:[k-1]};}while(i<left.length){a[k++]=left[i++];swaps++;yield {swap:[k-1]};}while(j<right.length){a[k++]=right[j++];swaps++;yield {swap:[k-1]};}}
function* divide(l,r){if(l>=r)return;let m=Math.floor((l+r)/2);yield* divide(l,m);yield* divide(m+1,r);yield* merge(l,m,r);}yield* divide(0,a.length-1);for(let i=0;i<a.length;i++)sortedIndices.add(i);}
function* quickSort(a){function* partition(low,high){let pivot=a[high],i=low;for(let j=low;j<high;j++){comparisons++;yield {compare:[j,high],pivot:high};if(order==='asc'?a[j]<pivot:a[j]>pivot){if(i!==j){[a[i],a[j]]=[a[j],a[i]];swaps++;yield {swap:[i,j],pivot:high};}i++;}}if(i!==high){[a[i],a[high]]=[a[high],a[i]];swaps++;yield {swap:[i,high]};}sortedIndices.add(i);return i;}
function* sort(low,high){if(low>high)return;if(low===high){sortedIndices.add(low);return;}let p=yield* partition(low,high);yield* sort(low,p-1);yield* sort(p+1,high);}yield* sort(0,a.length-1);for(let i=0;i<a.length;i++)sortedIndices.add(i);}
function* heapSort(a){function* heapify(n,i){let best=i,l=2*i+1,r=2*i+2;if(l<n){comparisons++;yield {compare:[l,best]};if(isOutOfOrder(a[best],a[l]))best=l;}if(r<n){comparisons++;yield {compare:[r,best]};if(isOutOfOrder(a[best],a[r]))best=r;}if(best!==i){[a[i],a[best]]=[a[best],a[i]];swaps++;yield {swap:[i,best]};yield* heapify(n,best);}}
// Build a max-heap for ascending, min-heap for descending.
for(let i=Math.floor(a.length/2)-1;i>=0;i--)yield* heapify(a.length,i);
for(let end=a.length-1;end>0;end--){[a[0],a[end]]=[a[end],a[0]];swaps++;sortedIndices.add(end);yield {swap:[0,end]};yield* heapify(end,0);}if(a.length)sortedIndices.add(0);}
const generatorMap={bubble:bubbleSort,selection:selectionSort,insertion:insertionSort,merge:mergeSort,quick:quickSort,heap:heapSort};
function buildGenerator(){return generatorMap[selectedAlgo](values);}
function finishSort(){setElapsedStopped();running=false;paused=false;stopRequested=false;stepMode=false;sortedIndices=new Set(values.map((_,i)=>i));renderBars();$('statusText').textContent='Sorted successfully';$('startLabel').textContent='Start sorting';$('startBtn').querySelector('.play-icon').textContent='▶';$('startBtn').disabled=false;$('stepBtn').disabled=false;$('shuffleBtn').disabled=false;$('sizeSlider').disabled=false;$('speedSlider').disabled=false;updateStats();}
function stopSort(resetStatus=false){stopRequested=true;running=false;paused=false;stepMode=false;if(stepResolve){stepResolve();stepResolve=null;}clearInterval(timerHandle);$('startBtn').disabled=false;$('stepBtn').disabled=false;$('shuffleBtn').disabled=false;$('sizeSlider').disabled=false;$('speedSlider').disabled=false;$('startLabel').textContent='Start sorting';$('startBtn').querySelector('.play-icon').textContent='▶';if(resetStatus)$('statusText').textContent='Ready to sort';}
function waitStep(){return new Promise(resolve=>{stepResolve=resolve;});}
async function runSort(singleStep=false){if(running&&!paused)return;if(paused&&!singleStep){paused=false;running=true;startedAt=performance.now();timerHandle=setInterval(updateElapsed,40);$('statusText').textContent='Sorting in progress';$('startLabel').textContent='Pause sorting';$('startBtn').querySelector('.play-icon').textContent='Ⅱ';await continueGenerator(false);return;}
  if(!generator || (!paused&&singleStep===false)){comparisons=0;swaps=0;sortedIndices=new Set();elapsedBefore=0;values=values.slice();generator=buildGenerator();}
  running=true;paused=false;stopRequested=false;stepMode=singleStep;startedAt=performance.now();timerHandle=setInterval(updateElapsed,40);$('startBtn').disabled=false;$('stepBtn').disabled=false;$('shuffleBtn').disabled=true;$('sizeSlider').disabled=true;$('statusText').textContent=singleStep?'Step mode':'Sorting in progress';$('startLabel').textContent=singleStep?'Continue sorting':'Pause sorting';$('startBtn').querySelector('.play-icon').textContent=singleStep?'▶':'Ⅱ';await continueGenerator(singleStep);
}
async function continueGenerator(single){let count=0;try{while(!stopRequested){if(paused&&!single)break;const next=generator.next();if(next.done){finishSort();generator=null;return;}const state=next.value||{};renderBars(state);updateStats();count++;if(single){paused=true;running=false;setElapsedStopped();$('statusText').textContent='Paused · one step complete';$('startLabel').textContent='Continue sorting';$('startBtn').querySelector('.play-icon').textContent='▶';$('stepBtn').disabled=false;$('shuffleBtn').disabled=false;$('sizeSlider').disabled=false;$('speedSlider').disabled=false;return;}await new Promise(resolve=>setTimeout(resolve,speedDelay()));}
  if(paused&&!stopRequested){setElapsedStopped();$('statusText').textContent='Paused';$('startLabel').textContent='Continue sorting';$('startBtn').querySelector('.play-icon').textContent='▶';$('shuffleBtn').disabled=false;$('sizeSlider').disabled=false;$('speedSlider').disabled=false;}
 }catch(e){console.error(e);stopSort();$('statusText').textContent='Something went wrong';}}
function pauseSort(){if(!running)return;paused=true;setElapsedStopped();$('statusText').textContent='Paused';$('startLabel').textContent='Continue sorting';$('startBtn').querySelector('.play-icon').textContent='▶';$('shuffleBtn').disabled=false;$('sizeSlider').disabled=false;$('speedSlider').disabled=false;}
function startOrPause(){if(running&&!paused){pauseSort();return;}if(paused){runSort(false);return;}runSort(false);}
function chooseAlgorithm(name){if(running||paused){stopSort(true);generator=null;}selectedAlgo=name;document.querySelectorAll('.algo-option').forEach(b=>b.classList.toggle('active',b.dataset.algo===name));updateAlgorithmInfo();resetStatsOnly();renderBars();}
function resetStatsOnly(){comparisons=0;swaps=0;elapsedBefore=0;$('elapsed').innerHTML='0.00<span class="stat-unit">s</span>';updateStats();$('statusText').textContent='Ready to sort';$('startLabel').textContent='Start sorting';$('startBtn').querySelector('.play-icon').textContent='▶';}
function resetAll(){stopSort(true);generator=null;sortedIndices=new Set();resetStatsOnly();renderBars();$('arrayCaption').textContent=`${values.length} values · random order`;}
function setOrder(next){if(order===next)return;order=next;document.querySelectorAll('.order-btn').forEach(b=>b.classList.toggle('active',b.dataset.order===order));$('orderValue').textContent=order==='asc'?'Ascending':'Descending';resetAll();}

document.querySelectorAll('.algo-option').forEach(b=>b.addEventListener('click',()=>chooseAlgorithm(b.dataset.algo)));
document.querySelectorAll('.order-btn').forEach(b=>b.addEventListener('click',()=>setOrder(b.dataset.order)));
$('sizeSlider').addEventListener('input',e=>{$('sizeValue').textContent=`${e.target.value} items`;if(!running&&!paused){randomArray(Number(e.target.value));}});
$('speedSlider').addEventListener('input',e=>{const v=Number(e.target.value);$('speedValue').textContent=v<30?'Slow':v<70?'Medium':'Fast';});
$('startBtn').addEventListener('click',startOrPause);
$('stepBtn').addEventListener('click',()=>{if(running&&!paused)pauseSort();if(!generator){runSort(true);}else if(paused){runSort(true);}else{runSort(true);}});
$('shuffleBtn').addEventListener('click',()=>{stopSort(true);generator=null;randomArray();});
$('resetBtn').addEventListener('click',resetAll);
document.addEventListener('keydown',e=>{if(e.code==='Space'&&!['INPUT','BUTTON'].includes(document.activeElement.tagName)){e.preventDefault();startOrPause();}if(e.key.toLowerCase()==='r'&&!['INPUT','BUTTON'].includes(document.activeElement.tagName))resetAll();});
updateAlgorithmInfo();$('speedValue').textContent='Medium';randomArray();
