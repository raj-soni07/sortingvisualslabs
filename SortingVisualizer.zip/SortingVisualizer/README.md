# SortLab — Sorting Algorithm Visualizer

A colourful, responsive sorting visualizer made with plain HTML, CSS, and JavaScript.

## Included algorithms
- Bubble Sort
- Selection Sort
- Insertion Sort
- Merge Sort
- Quick Sort
- Heap Sort

## Features
- Animated bars and colour-coded comparisons, swaps, pivots, and sorted values
- Array size and animation speed controls
- Ascending and descending order
- Start / pause / continue, single-step, new array, and reset controls
- Live comparison, swap, elapsed-time, and complexity statistics
- Short learning notes and complexity summaries for each algorithm
- Responsive layout for desktop and mobile

## Run it
1. Extract the ZIP file.
2. Open the `SortingVisualizer` folder in VS Code.
3. Open `index.html` in a browser. You can also use the VS Code Live Server extension.

No npm install, build command, or server is required. The Google Fonts import is optional; the page uses fallback fonts if offline.
